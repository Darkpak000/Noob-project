# multi-bruteforce-facebook
# author pirmansx
# dragonfly zombie team
# language python 2

Cara gunakan:
python2 MBF.py
module ekstra
pip2 install mechanize


I just want say do not use this tool for illegal purpos
Jika ada bug silah kan beritahu saya....
Jika ada saran silah kan beritahu saya
